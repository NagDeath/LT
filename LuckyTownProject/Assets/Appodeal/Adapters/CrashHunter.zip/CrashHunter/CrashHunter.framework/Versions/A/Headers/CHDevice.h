//
//  CHPlatform.h
//  CrashHunter
//
//  Created by Stas Kochkin on 21/12/2016.
//  Copyright © 2016 Appodeal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <KSCrash/KSCrash.h>

void ch_populateDeviceInfo(const KSCrashReportWriter * writer);

@interface CHDevice : NSObject



@end
