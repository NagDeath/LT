//
//  CHReport.h
//  CrashHunter
//
//  Created by Stas Kochkin on 14/12/2016.
//  Copyright © 2016 Appodeal. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CHReport : NSObject

- (instancetype)initWithCrashReport:(NSDictionary *)crashReport;

- (NSDictionary *)JSONRepresentation;

@end
