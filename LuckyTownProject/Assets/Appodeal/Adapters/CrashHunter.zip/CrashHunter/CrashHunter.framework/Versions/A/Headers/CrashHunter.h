//
//  CrashHunter.h
//  CrashHunter
//
//  Created by Stas Kochkin on 14/12/2016.
//  Copyright © 2016 Appodeal. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CrashHunter : NSObject

+ (instancetype)sharedInstance;

- (void)install;

- (void)setCustomData:(NSDictionary *)customData;

- (void)storeException:(NSException *)exception;

- (void)sendReportsFatal:(BOOL)fatal completion:(void (^)(BOOL, NSError *))completion;

- (void)clearReportStorage;

@end




