//
//  CHReportSender.h
//  CrashHunter
//
//  Created by Stas Kochkin on 14/12/2016.
//  Copyright © 2016 Appodeal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CHNetworkClientProtocol.h"

@class CHReportSender;

@protocol CHReportSenderDelegate <NSObject>

- (void)reportSenderSuccessfullySendReports:(CHReportSender *)reportSender;
- (void)reportSender:(CHReportSender *)reportSender failWithError:(NSError *)error;


@end

@interface CHReportSender : NSObject

@property (nonatomic, weak) id <CHReportSenderDelegate> delegate;

- (instancetype)initWithNetworkClient:(id <CHNetworkClient>)networkClient;
- (void)sendReports:(NSArray *)reports;

@end
