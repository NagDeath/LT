//
//  KSCrash+CHStore.h
//  CrashHunter
//
//  Created by Stas Kochkin on 18/01/2017.
//  Copyright © 2017 Appodeal. All rights reserved.
//

#import <KSCrash/KSCrash.h>

@interface KSCrash (CHStore)

@property (nonatomic, readonly) NSString * basePath;

@end
